version = "2.0.0"
from .core import OpenAIQueryHandler
from .lib import roleDict, refineDict, extDict
